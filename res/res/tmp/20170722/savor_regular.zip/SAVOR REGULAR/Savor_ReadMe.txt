
=== SAVOR REGULAR ===
=== SAVOR BOLD ===
=== SAVOR ITALIC ===
=== SAVOR BOLD ITALIC ===

Keith Bates / K-Type © 2011 (version 1.01)
www.k-type.com    -    info@k-type.com

Savor is a script-ish family designed to look just as good all in capitals as it does in title or lower case. It’s a typeface that suggests exotic, it’s lively and luscious, flamboyant yet dignified.

------------------------------------------------

== Licence Information ==

Licence URL: http://www.k-type.com/licences

------------------------------------------------

== Installing Fonts ==

Fonts are placed in your operating system's Fonts folder and will be made available to all the applications or programs you use.

= Windows =
Put the .ttf or .otf font file into C:\Windows\Fonts, or right-click on the font files > Install

= Mac =
Put the .ttf or .otf font file into /Library/Fonts

------------------------------------------------